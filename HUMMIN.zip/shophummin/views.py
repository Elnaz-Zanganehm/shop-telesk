from django.shortcuts import render
from . import models

def index(request):
    product_list = models.Product.objects.all()[:4]
    return render(request, 'index.html', {'product_list': product_list})

def checkout(request):
    return render(request, 'checkout.html')


def product(request):
    return render(request, 'product.html')


